Huji-Lab is a package that helps you save time in analyzing data gathered from experiments at the Huji Physics Lab Course.<br>
The package is mostly a wrapper for other packages, with more straight-to-the-point interface. <br><br>
I customized the different functions to my own needs, but you are more than welcome to suggest improvements, point out bugs and contribute code bits and ideas.<br>